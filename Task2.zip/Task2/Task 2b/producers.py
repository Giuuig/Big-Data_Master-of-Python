import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

dataset_A = pd.read_excel('DatasetA.xlsx')
dataset_B = pd.read_excel('DatasetB.xlsx')
"""
Visto che nel file excel ci è stato chiesto di utilizzare la deviazione standard calibrata sulla popolazione e non sul campipone,
la utilizziamo allo stesso modo anche qua. La differenza con quella campionaria, in questo contesto, sarebbe bassa
"""
stdA = dataset_A.std(ddof=0)
stdB = dataset_B.std(ddof=0)
mnA = dataset_A.mean()
mnB = dataset_B.mean()

print("deviazione standard di A: ", stdA)
print("media di A: ", mnA)
print("deviazione standard di B: ", stdB)
print("media di B: ", mnB)

#In questa parte, invece, andiamo a generare la distribuzione normale calcolando i dati campionari della variabile

#Genero due liste per ciascun dataset. Sull'asse X inseriremo i valori relativi alla probability density function applicata sulla durata di ogni batteria
#Sull'asse delle ordinate inserirò la durata delle batterie del dataset

#assi per il dataset A
x_values_A = []
y_values_A = []
#assi per il dataset B
x_values_B = []
y_values_B = []

#Riempio le liste legate ai due dataset
for alpha in dataset_A['Vita batteria (in mesi)']:
    pdfA = norm.pdf(alpha, mnA, stdA)
    y_values_A.append(pdfA)
    x_values_A.append(alpha)

for beta in dataset_B['Vita batteria (in mesi)']:
    pdfB = norm.pdf(beta, mnB, stdB)
    y_values_B.append(pdfB)
    x_values_B.append(beta)

#Genero la figura in cui andare a mettere il subplot dei prodotti di A e di B
fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(12, 6), sharex=True)

#Creo il subplot dei prodotti dell'azienda A
axs[0].plot(x_values_A, y_values_A, marker='.', linestyle='-', color="#fccb05", label="Produttore A")
axs[0].set_title("Produttore A")
axs[0].set_xlabel("Valori rilevati nell'esperimento A")
axs[0].set_ylabel("Densità di Probabilità")
axs[0].grid(True)
plt.xlim(0,100)

#Genero il subplot dei prodotti dell'azienda B
axs[1].plot(x_values_B, y_values_B, marker='.', linestyle='-', color="#03c6fc", label="Produttore B")
axs[1].set_title("Produttore B")
axs[1].set_xlabel("Valori rilevati nell'esperimento B")
axs[1].set_ylabel("Densità di Probabilità")
axs[1].grid(True)
plt.ylim(0,2)
plt.xlim(0,100)

#Regolo lo spazio tra i due grafici e li dispongo
plt.tight_layout()
plt.show()