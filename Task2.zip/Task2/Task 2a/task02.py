import matplotlib.pyplot as plt
import numpy as np

fig, alpha = plt.subplots()
"""
Abbiamo costruito una lista che contiene i valori da disporre sull'asse delle ascisse
Questi sono i valori potenzialmente ottenibili sommando il risultato di due lanci di dadi
"""
x_values = [2,3,4,5,6,7,8,9,10,11,12]
"""
Abbiamo deciso di costruire un dizionario. Nelle chiavi abbiamo messo le somme che si possono ottenere.
Per ogni chiave, il valore attribuito è una tupla contente a sua volta delle tuple. Nelle tuple interne abbiamo inserito tutte le coppie che, sommate, ci danno
il risultato riportato sulla chiave.
Abbiamo scelto di usare questa combinazione di strutture dati per una questione di leggiblità del codice e per renderlo scalabile
"""
somma_dadi = {"due":((1,1),),
              "tre":((1,2),(2,1)),
              "quattro":((1,3),(2,2),(2,1)),
              "cinque":((1,4),(4,1),(2,3),(3,2)),
              "sei":((1,5),(5,1),(4,2),(2,4),(3,3)),
              "sette":((5,2),(2,5),(6,1),(1,6),(4,3),(3,4)),
              "otto":((6,2),(2,6),(5,3),(3,5),(4,4)),
              "nove":((6,3),(3,6),(5,4),(4,5)),
              "dieci":((5,5),(6,4),(4,6)),
              "undici": ((6,5),(5,6)),
              "dodici": ((6,6),)
              }
"""
Per l'asse delle ordinate, abbiamo bisogno di disporre la probabilità con cui possiamo ottenere ciascuna somma.
Allora, la soluzione che abbiamo pensato è stata quella di salvare in una lista i valori attribuiti a ciascuna chiave (nell'index 0 inseriamo i valori della chiave "due" e così via)
Adesso che abbiamo una lista di tuple, ossia di casi in cui possiamo ottenere un certo valore, la strategia che adottiamo è la seguente:
Eseguiamo con un ciclo for lo scorrimento della lista e usiamo il metodo len() per calcolare la lunghezza della tupla presa in esame (ossia, troviamo il numero di combinazioni per una certa somma)
Per la nozione di probabilità frequentista, ci basta dividere questo dato per 36 per trovare la probabilità di una certa somma. Il dato trovato verrà aggiunto ad un array, che ci servirà
per costruire l'asse delle ordinate quando andremo a generare il grafico.
"""
valori = somma_dadi.values()
y_values = []
i=0

for x in valori:
    n_combinazioni = len(x)
    #print(n_combinazioni)
    p = n_combinazioni/36
    y_values.append(p)

#Eseguiamo dei setting per rendere più leggibile il grafico
label_set = ['due','tre','quattro','cinque','sei','sette','otto','nove','dieci','undici','dodici']
color_set = ['#5c0618', '#960623', '#bd082c', '#e30935', '#e3002d', '#ff8aa1', '#e3002d', '#e30935', '#bd082c', '#960623', '#5c0618']
alpha.bar(x_values, y_values, color=color_set, linewidth=2, tick_label=label_set)
alpha.set_ylabel('Probabilita')
alpha.set_title('Probabilità di ottenere un certo valore sommando il lancio di due dadi')
plt.show()