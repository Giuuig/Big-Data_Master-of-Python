import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB

#Inserimento dei dati di training in una lista per praticità e poi l'abbiamo trasformato in un dataframe
data={
      "keyword":["offerta", "offerta", "offerta", "offerta", "money", "money", "money", "viagra", "viagra", "viagra"],
      "lunghezza":["lunga", "lunga", "corta", "media", "media", "lunga", "corta", "lunga", "lunga", "media"],
      "intestaz.":["si", "no", "no", "si", "no", "si", "no", "si", "no", "no"],
      "VALIDA?":["si", "si", "no", "si", "no", "no", "no", "no", "si", "no"]
  }
df=pd.DataFrame(data)

#Encoding delle feature
keywords=LabelEncoder()
lunghezza=LabelEncoder()
intestazione=LabelEncoder()
valida=LabelEncoder()

df["keyword_enc"]=keywords.fit_transform(df["keyword"])
df["lunghezza_enc"]=lunghezza.fit_transform(df["lunghezza"])
df["intestaz_enc"]=intestazione.fit_transform(df["intestaz."])
df["valida_enc"]=valida.fit_transform(df["VALIDA?"])

#Definizione delle liste con i valori da inserire in input (X) e dei valori in output (Y)
X=df[["keyword_enc","lunghezza_enc","intestaz_enc"]]
y=df["valida_enc"]

#Addestramento del modello
gnb = GaussianNB()
gnb.fit(X, y)

#Dati della nuova email da classificare
new_email=pd.DataFrame([{
    "keyword_enc":keywords.transform(["offerta"])[0],
    "lunghezza_enc":lunghezza.transform(["media"])[0],
    "intestaz_enc":intestazione.transform(["si"])[0]
}])

#Predizione
predizione = gnb.predict(new_email)
label_predizione = valida.inverse_transform(predizione)[0]

print(f"La nuova email è valida?:{label_predizione.upper()}")