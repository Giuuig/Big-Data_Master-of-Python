import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, export_graphviz, export_text
import graphviz

data = {
    "keyword": ["offerta", "offerta", "offerta", "offerta", "money", "money", "money", "viagra", "viagra", "viagra"],
    "lunghezza": ["lunga", "lunga", "corta", "media", "media", "lunga", "corta", "lunga", "lunga", "media"],
    "intestaz": ["si", "no", "no", "si", "no", "si", "no", "si", "no", "no"],
    "valida": ["si", "si", "no", "si", "no", "no", "no", "no", "si", "no"]
}
df = pd.DataFrame(data)

#Encoding delle colonne
encoders = {}
for column in ["keyword", "lunghezza", "intestaz", "valida"]:
    le = LabelEncoder()
    df[column + "_enc"] = le.fit_transform(df[column])
    encoders[column] = le

#Definiamo feature set e target
X = df[["keyword_enc", "lunghezza_enc", "intestaz_enc"]]
y = df["valida_enc"]

#Addestriamo dell'albero decisionale
clf = DecisionTreeClassifier(criterion="entropy", random_state=42)
clf.fit(X, y)

#Qui effettuiamo una stampa testuale a console_log dell'albero di decisione
albero_testuale = export_text(clf, feature_names=["keyword_enc", "lunghezza_enc", "intestaz_enc"])
print("\nAlbero Decisionale (versione testuale):\n")
print(albero_testuale)

#Per completezza, abbiamo deciso di creare una versione analoga su Graphviz
dati_albero = export_graphviz(
    clf,
    out_file=None,
    feature_names=["keyword_enc", "lunghezza_enc", "intestaz_enc"],
    class_names=encoders["valida"].classes_,
    filled=True,
    rounded=True,
    special_characters=True
)
graph = graphviz.Source(dati_albero)
graph.render("albero_decisionale", format="png", cleanup=True)
graph.view()

#Dati della nuova mail
nuova_email = {
    "keyword": "offerta",
    "lunghezza": "media",
    "intestaz": "si"
}

#Codifica e predizione
nuovi_dati = pd.DataFrame([{
    "keyword_enc": encoders["keyword"].transform([nuova_email["keyword"]])[0],
    "lunghezza_enc": encoders["lunghezza"].transform([nuova_email["lunghezza"]])[0],
    "intestaz_enc": encoders["intestaz"].transform([nuova_email["intestaz"]])[0]
}])

predizione = clf.predict(nuovi_dati)[0]
etichetta = encoders["valida"].inverse_transform([predizione])[0]

print(f"\nRisultato classificazione nuova email: {etichetta.upper()}")
