import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dati = pd.read_excel('DatiPopolazioniCitta_ripulito.xlsx')

#Selezioniamo i campi del dataset relativi alla popolazione alla data del primo gennaio e li salviamo in una lista
dati_popolazione = dati[dati['Tipo di indicatore demografico'] == 'popolazione al 1º gennaio']

"""
Effettuiamo un parsing degli attributi nella colonna Value, poiché abbiamo importato un file in formato .csv. 
In seguito, puliamo il dataframe rimuovendo le righe che presentano valori nulli nel campo Value
"""
dati_popolazione['Value'] = pd.to_numeric(dati_popolazione['Value'], errors='coerce')
dati_popolazione = dati_popolazione.dropna(subset=['Value'])  

#Per una questione operativa, abbiamo deciso di effettuare un ordinamento per valore dei territori oggetto di questo studio
popolazioni = dati_popolazione[['Territorio', 'Value']].sort_values(by='Value', ascending=False)

#Costruiamo il grafico a barre verticale per la popolazione delle province
plt.bar(popolazioni['Territorio'], popolazioni['Value'], color='#e942f5')
plt.title('Popolazione delle Province in Italia', fontsize=16)
plt.xlabel('Provincia', fontsize=14)  
plt.ylabel('Popolazione', fontsize=14) 
plt.tick_params(axis='x', rotation=90) 
plt.tight_layout()
plt.show()

#Grafico, ma in scala logaritmica
log_positions = np.log10(range(1, len(popolazioni) + 1)) 
log_popolazioni = np.log10(popolazioni['Value']) 

plt.bar(log_positions, log_popolazioni, color='orange')
plt.title('Distribuzione Log-Log della Popolazione delle Province Italiane', fontsize=16)
plt.xlabel('Log(Posizione Provincia)', fontsize=14)  
plt.ylabel('Log(Popolazione)', fontsize=14)  
plt.tight_layout()
plt.show()

