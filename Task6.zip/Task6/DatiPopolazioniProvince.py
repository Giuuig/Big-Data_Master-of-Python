import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dati = pd.read_excel('DatiPopolazioniCitta_ripulito.xlsx')

dati_popolazione = dati[dati['Tipo di indicatore demografico'] == 'popolazione al 1º gennaio']

dati_popolazione['Value'] = pd.to_numeric(dati_popolazione['Value'], errors='coerce')
dati_popolazione = dati_popolazione.dropna(subset=['Value'])

popolazioni = dati_popolazione[['Territorio', 'Value']].sort_values(by='Value', ascending=False)

#Grafico classico
plt.bar(popolazioni['Territorio'], popolazioni['Value'], color='#e942f5')
plt.title('Popolazione delle Province in Italia', fontsize=16)
plt.xlabel('Provincia', fontsize=14)
plt.ylabel('Popolazione', fontsize=14)
plt.tick_params(axis='x', rotation=90)
plt.tight_layout()
plt.show()

#Grafico log-log
log_popolazioni = np.log10(popolazioni['Value'])

plt.bar(popolazioni['Territorio'], log_popolazioni, color='#f59542')
plt.title('Distribuzione Log-Log della Popolazione delle Province Italiane', fontsize=16)
plt.xlabel('Provincia', fontsize=14)
plt.ylabel('Log(Popolazione)', fontsize=14)
plt.tick_params(axis='x', rotation=90)
plt.tight_layout()
plt.show()