import pandas as pd

df = pd.read_csv("C:\\Users\\anton\\Desktop\\Uninsubria\\Anno II\\24.25\\Big Data\\Tasks\\Task6\\DatiPopolazioniCitta.csv")
df.to_excel('DatiPopolazioniCitta.xlsx', index=False)