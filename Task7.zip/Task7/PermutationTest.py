import random
import matplotlib.pyplot as plt
from collections import Counter

n = 4
iterazioni = 1000000
elementi = [1, 2, 3, 4]

contatore = Counter()

#Esecuzione di un milione di run
for x in range(iterazioni):
    permutazione = elementi[:]  #Copia della lista originale gli elementi della permutazione. Per definizione, la permutazione avrà lo stesso numero di elementi del dominio
    random.shuffle(permutazione) #Mescolamento a caso gli elementi copiati per ottenere una possibile permutazione
    contatore[tuple(permutazione)] += 1

#Per una questione di ordine, si è effettuato il sorting delle permutazioni che sono state costruite. Questo agevola nella generazione del grafico
permutazioni = sorted(contatore.keys())
frequenze = [contatore[p] for p in permutazioni] #Conta di quante volte compaiono le varie permutazioni
classi_perm = [str(p) for p in permutazioni] #Costruzione delle classi di equivalenza da inserire nell'asse delle ascisse

plt.figure(figsize=(12, 6))

media_frequenze = sum(frequenze) / len(frequenze)
bars = plt.bar(classi_perm, frequenze, color='#f7af05', label='Frequenze')
plt.axhline(media_frequenze, color='black', linestyle='--', linewidth=1, label=f'Linea di trend (media ≈ {media_frequenze:.1f})')

plt.xlabel('Permutazioni')
plt.ylabel('Numero di apparizioni')
plt.legend()
plt.title('Frequenza assoluta di apparizione di permutazioni da 4 elementi(1.000.000 di esperimenti)')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
