import random
import matplotlib.pyplot as plt
from collections import Counter

#Per eseguire questo test abbiamo bisogno del numero di elementi che compongono le permutazioni, gli elementi con cui generiamo le permutazioni e il numero di iterazioni del test
n = 4
iterazioni = 1000000
elementi = [1, 2, 3, 4]

"""
Per facilitarci le cose, abbiamo deciso di importare dalla libreria collections la classe Counter.
Al suo interno, contiamo quante volte viene generata la stessa permutazione
"""
contatore = Counter()

#Esecuzione di un milione di run in cui generiamo una permutazione per ogni iterazione del ciclo
for x in range(iterazioni):
    permutazione = elementi[:]  #Copia della lista originale gli elementi della permutazione. Per definizione, la permutazione avrà lo stesso numero di elementi del dominio
    random.shuffle(permutazione) #Mescolo a caso gli elementi copiati per ottenere una possibile permutazione
    contatore[tuple(permutazione)] += 1

#Per una questione di ordine, abbiamo deciso di effettuare un sorting delle permutazioni che sono state costruite. Così poi possiamo generare il grafico
permutazioni = sorted(contatore.keys())
frequenze = [contatore[p] for p in permutazioni] #Contiamo quante volte compaiono le varie permutazioni
classi_perm = [str(p) for p in permutazioni] #Costruiamo delle classi di equivalenza da inserire nell'asse delle ascisse

#Settin per il grafico a barre
plt.figure(figsize=(12, 6))
plt.bar(classi_perm, frequenze, color='#f7af05')
plt.xlabel('Permutazioni')
plt.ylabel('Numero di apparizioni')
plt.title('Frequenza assoluta di apparizione di permutazioni da 4 elementi(1.000.000 di esperimenti)')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
