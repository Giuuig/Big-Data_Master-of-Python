import random
import matplotlib.pyplot as plt
from collections import Counter
import math

n = 4
iterazioni = 1000000
elementi = [1, 2, 3, 4]

contatore = Counter()

#Esecuzione di un milione di run
for x in range(iterazioni):
    permutazione = elementi[:]  #Copia della lista originale gli elementi della permutazione. Per definizione, la permutazione avrà lo stesso numero di elementi del dominio
    random.shuffle(permutazione) #Mescolamento a caso gli elementi copiati per ottenere una possibile permutazione
    contatore[tuple(permutazione)] += 1

#Per una questione di ordine, si è effettuato il sorting delle permutazioni che sono state costruite. Questo agevola nella generazione del grafico
permutazioni = sorted(contatore.keys())
frequenze = [contatore[p] for p in permutazioni] #Conta di quante volte compaiono le varie permutazioni
classi_perm = [str(p) for p in permutazioni] #Costruzione delle classi di equivalenza da inserire nell'asse delle ascisse

plt.figure(figsize=(12, 6))

media_frequenze = sum(frequenze) / len(frequenze)
bars = plt.bar(classi_perm, frequenze, color='#f7af05', label='Frequenze')
plt.axhline(media_frequenze, color='black', linestyle='--', linewidth=1, label=f'Linea di trend (media ≈ {media_frequenze:.1f})')

plt.xlabel('Permutazioni')
plt.ylabel('Numero di apparizioni')
plt.legend()
plt.title('Frequenza assoluta di apparizione di permutazioni da 4 elementi(1.000.000 di esperimenti)')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()

#Quantità di punti da campionare, definizione del raggio, creazione di liste per le coordinate da memorizzare
n_punti = 10000
raggio = 1 
x_coords = []
y_coords = []

#Campionamento uniforme 
for _ in range(n_punti):
    theta = random.uniform(0, 2 * math.pi)  #Angolo distribuito in modo uniforme (valore da 0 compreso a 2*pi-greco)
    r = math.sqrt(random.uniform(0, 1)) * raggio
    x_coords.append(r * math.cos(theta))
    y_coords.append(r * math.sin(theta))

# Visualizzazione dei punti campionati
plt.figure(figsize=(10, 10))
plt.scatter(x_coords, y_coords, s=1, color='#f7af05')
circle = plt.Circle((0, 0), raggio, edgecolor='black', facecolor='none', linewidth=1)
plt.gca().add_patch(circle)

plt.title('Campionamento uniforme con 10000 punti selezionati in maniera casuale')
plt.xlabel('x')
plt.ylabel('y')
plt.gca().set_aspect('equal', 'box')
plt.tight_layout()
plt.show()

