import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import ttest_ind, norm, ks_2samp

df = pd.read_csv('/content/qi30k.csv')

maschi = df[df['Genere'] == 'Maschio']['Quoziente']
femmine = df[df['Genere'] == 'Femmina']['Quoziente']

#Esecuzione del T-test 
t_stat, p_value = ttest_ind(maschi, femmine, equal_var=False)
print("Il risultato del t-test è:", t_stat)
if p_value<0.05:
    print("Il p-value del t-test è ", p_value, " pertanto il risultato del test è significativo")
else:
    print("Il p-value del t-test è ", p_value, " pertanto, il risultato del test non è significativo")

#Esecuzione del KS-Test
ks_stat, ks_p_value = ks_2samp(maschi, femmine)
print("Il risultato del test di Kolmogorov-Smirnov:", ks_stat)
if ks_p_value<0.05:
    print("Il p-value del KS-Test è ", ks_p_value, " pertanto il risultato del test è significativo")
else:
    print("Il p-value del KS-Test è ", ks_p_value, " pertanto, il risultato del test non è significativo")

#Delineazione della distribuzione normale dei due gruppi(ai fini del grafico)
mean_m = maschi.mean()
std_m = maschi.std()
mean_f = femmine.mean()
std_f = femmine.std()

#Range di valori per illustrare il grafico delle due distribuzioni normali
xmin = min(maschi.min(), femmine.min()) - 10
xmax = max(maschi.max(), femmine.max()) + 10
x_range = np.linspace(xmin, xmax, 200)

pdf_m = norm.pdf(x_range, mean_m, std_m)
pdf_f = norm.pdf(x_range, mean_f, std_f)

fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(10,6))

#Istogrammi che graficano i risultati per ciascun gruppo
axs[0].hist(maschi, bins=30, density=True, alpha=0.3, label='Maschi', color='#0094f7')
axs[0].hist(femmine, bins=30, density=True, alpha=0.3, label='Femmine', color='#f70084')
axs[0].set_xlabel("Livello di QI rilevato")
axs[0].set_ylabel("Frequenza (dato discreto)")

#Grafici recanti la distribuzione normale di maschi e femmine, a confronto
axs[1].fill_between(x_range, pdf_m, color='#0094f7', alpha=0.5, label='Distribuzione Normale Maschi')
axs[1].fill_between(x_range, pdf_f, color='#f70084', alpha=0.5, label='Distribuzione Normale Femmine')
axs[1].set_xlabel("Livello di QI rilevato")
axs[1].set_ylabel("Frequenza (in densità di probabilità)")

fig.legend()
plt.show()