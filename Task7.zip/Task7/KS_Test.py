import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import ks_2samp, norm

df = pd.read_csv('qi30k.csv')

maschi = df[df['Genere'] == 'Maschio']['Quoziente']
femmine = df[df['Genere'] == 'Femmina']['Quoziente']

# Esecuzione del KS-Test per verificare se le due distribuzioni differiscono
ks_stat, ks_p_value = ks_2samp(maschi, femmine)
print("Il risultato del test di Kolmogorov-Smirnov:", ks_stat)
if ks_p_value<0.05:
    print("Il p-value è ", ks_p_value, " pertanto il risultato del test è significativo")
else:
    print("Il p-value è ", ks_p_value, " pertanto, il risultato del test non è significativo")

# Calcolo della media e della deviazione standard per ciascun gruppo (utili per il grafico)
mean_m = maschi.mean()
std_m = maschi.std()
mean_f = femmine.mean()
std_f = femmine.std()

# Creazione di un range di valori IQ per il grafico
xmin = min(maschi.min(), femmine.min()) - 10
xmax = max(maschi.max(), femmine.max()) + 10
x = np.linspace(xmin, xmax, 200)
pdf_m = norm.pdf(x, mean_m, std_m)
pdf_f = norm.pdf(x, mean_f, std_f)

# Creazione del grafico
plt.figure(figsize=(10, 6))
plt.plot(x, pdf_m, label='Maschi', lw=2)
plt.plot(x, pdf_f, label='Femmine', lw=2)
plt.xlabel('Quoziente Intellettivo')
plt.ylabel('Densità di Probabilità')
plt.title('Distribuzioni del Quoziente Intellettivo (KS-Test)')
plt.legend()
plt.grid(True)
plt.show()
