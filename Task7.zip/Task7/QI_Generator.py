import numpy as np
import pandas as pd

# Imposta il numero di rilevazioni
n = 30000

# Per garantire la riproducibilità
np.random.seed(42)

# Genera il quoziente come numero intero, distribuito normalmente (media 100, std 15)
quozienti = np.random.normal(100, 15, n).round().astype(int)

# Genera casualmente il sesso
sesso = np.random.choice(['Maschio', 'Femmina'], n)

# Crea il DataFrame
df = pd.DataFrame({'Quoziente': quozienti, 'Sesso': sesso})

# Salva il DataFrame in formato CSV
df.to_csv('dataset.csv', index=False)


