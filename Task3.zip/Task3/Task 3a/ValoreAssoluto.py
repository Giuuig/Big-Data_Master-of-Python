import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr

#Lista contenete i parametri di funzione e lista contenente gli output di funzione

x_values=[]
y_values=[]

for x in range(-8,9):
    x_values.append(x)

for x in x_values:
    y = abs(x)
    y_values.append(y)

#Calcolo del coefficiente di Pearson ed il relativo p-value
prs, p_value = pearsonr(x_values, y_values)
print("Il coefficiente di Pearson calcolato per la funzione di valore assoluto e' >", prs)
if(p_value <0.05):
  print("Questa rilevazione risulta significativa")
if(p_value >= 0.05):
  print("Questa rilevazione risulta non significativa")

#Genero il grafico di funzione
plt.plot(x_values, y_values, linestyle='--', marker='.', label='Grafico della funzione valore assoluto f(x)=|x|', color="#03c6fc", markersize=12)
plt.grid(True)
plt.show()