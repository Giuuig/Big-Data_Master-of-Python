import numpy as np
import matplotlib.pyplot as plt

#ob: bisogna implementare la funzione di valore assoluto e calcolare il coefficiente di Pearson per eseguire una correlazione

#genero una lista contenete i parametri di funzione e una lista contenente gli output di funzione

x_values=[]
y_values=[]

for x in range(-8,9):
    x_values.append(x)

for x in x_values:
    y = abs(x)
    y_values.append(y)

#Calcolo la matrice di correlazione con una funzione della libreria numpy
matrix = np.corrcoef(x_values, y_values)
#uso la matrice per calcolare il coefficiente di Pearson. Inserisco a parametro [0,1] perché sto correlando x_values (0) e y_values(1)
prs = matrix[0,1]
print("Il coefficiente di Pearson calcolato sui dati della funzione valore assoluto è: >", prs)
print(matrix)

#Genero il grafico di funzione
plt.plot(x_values, y_values, linestyle='--', marker='.', label='Grafico della funzione valore assoluto f(x)=|x|', color="#03c6fc", markersize=12)
plt.grid(True)
plt.show()