import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr

frame = pd.read_excel('Traffico Milano.xlsx')

#Costruzione di una lista contenente i valori del traffico e una contenente i giorni del mese, espressi sottoforma di valore numerico (da 0 a 28)
values = []
for x in frame['Traffico']:
    values.append(x)

days = []
for y in range(0,28):
    days.append(y)

#Qui sono state "settate" le variabili e le liste necessarie all'esecuzione dello shift
riferimento = values[:7]
lags = []
correlations = []
n = len(values)
group = values[0:7]


for shift in range(n):
    if(len(group)<3):
        break
    if(len(group)<7):
        a = len(group)
        r, p_value = pearsonr(riferimento[:a], group[:a])
        lags.append(shift)
        correlations.append(r)
        group = values[shift+1:shift+7+1]
    else:
        r, p_value = pearsonr(riferimento, group)
        lags.append(shift)
        correlations.append(r)
        group = values[shift+1:shift+7+1]

fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(10, 5), sharex=False)
axs[0].plot(days, values, marker='.', color='#07c3ed', markersize=8)
axs[0].set_xlabel("Giorno del mese")
axs[0].set_ylabel("Traffico giornaliero")
axs[0].set_title("Traffico nella città di Milano")
axs[0].grid(True)
axs[1].plot(lags, correlations, marker='.', color='#edc707', markersize=12)
axs[1].set_xlabel("Shift")
axs[1].set_ylabel("Coefficiente di correlazione")
axs[1].set_title("Autocorrelazione sulle rilevazioni del traffico di Milano")
axs[1].grid(True)
plt.show()