import pandas as pd
import numpy as np
from scipy.stats import spearmanr
from scipy.stats import pearsonr
import matplotlib.pyplot as plt

dati = pd.read_excel('Tabella di Mollier.xlsx')

x_values = []
for x in dati['T']:
    x_values.append(x)
x_values.pop(0)

y_values = []
for y in dati['V_l']:
    y_values.append(y)
y_values.pop(0)

#Calcolo del coefficiente di Pearson
prs, p_value_prs = pearsonr(x_values, y_values)
print("Il coefficiente di Pearson calcolato sui valori T e V_l della tabella di Mollier e' >", prs)

if(p_value_prs < 0.05):
    print("Questa correlazione di Pearson e' significativa perché il p value e' >",p_value_prs)
else:
    print("Questa correlazione di Pearson e'poco significativa perche' il p-value è di >",p_value_prs)

#Calcolo del coefficiente di Spearman
spr, p_value_spr = spearmanr(x_values, y_values)
print("Il coefficiente di Spearman calcolato sui valori T e V_l della tabella di Mollier e' >", spr)

if(p_value_spr < 0.05):
    print("Questa correlazione di Spearman e' significativa perche' il p-value e'>",p_value_spr)
else:
    print("Questa correlazione di Spearman e' poco significativa perche' il p-value e' >",p_value_spr)

#Coefficiente angolare della retta di tendenza
m = np.dot(x_values, y_values) / np.dot(x_values, x_values)

#Costruzione della retta di tendenza
x_coord = np.linspace(min(x_values), max(x_values), 100)
y_coord = m * x_coord

plt.scatter(x_values, y_values, marker='.', s=100, edgecolor='black', color='#fcba03')
plt.plot(x_coord, y_coord, color='black', linestyle='--', linewidth=1)
plt.ylim(0,0.3)
plt.xlim(0,400)
plt.grid(True)
plt.show()