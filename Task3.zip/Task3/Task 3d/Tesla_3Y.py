import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr


df = pd.read_excel('TSLA.xlsx')
#Parsing a datetime in quanto, durante la conversione da csv a xlsx del file, non è stato possibile riportare il formato "Data" alla colonna
df['Date']= pd.to_datetime(df['Date'])

#Filtraggio delle date per selezionare solo quelle necessarie all'esperimento
data = df.loc[(df['Date']>='2018-02-01') & (df['Date']<'2021-02-02'), ['Date', 'Adj Close']]

closures = []
n=0
days=[]

#Salvataggio dei valori di Closure e delle Date del periodo interessato in due liste omonime
for x in data['Adj Close']:
    closures.append(x)

for y in data['Date']:
    days.append(n)
    n=n+1

#Shift correlation effettuata con un ragionamento analogo a quanto avvenuto nel punto precedente del task
riferimento = closures[:30]
lags = []
correlations = []
r2 = []
p_values = []
n = len(closures)
group = closures[0:30]

for shift in range(n):
    if (len(group)<2):
        break
    if (len(group) < 30):
        a = len(group)
        r, p_value = pearsonr(riferimento[:a], group[:a])
        lags.append(shift)
        correlations.append(r)
        r2.append(r**2)
        p_values.append(p_value)
    else:
        r, p_value = pearsonr(riferimento, group)
        lags.append(shift)
        correlations.append(r)
        r2.append(r**2)
        p_values.append(p_value)
    group = closures[shift+1:shift+30+1]

fig, axs = plt.subplots(nrows=2, ncols=2, figsize=(30, 10), sharex=False)
axs[0][0].plot(days, closures, marker='.', color='#07c3ed', markersize=2)
axs[0][0].set_xlabel("Giorno esaminato")
axs[0][0].set_ylabel("Closure value giornaliero")
axs[0][0].set_title("Evoluzione del valore di TSLA tra il 01/02/2018 ed il 02/02/2021")
axs[0][0].grid(True)

axs[0][1].plot(lags, correlations, marker='.', color='#edc707', markersize=2)
axs[0][1].set_xlabel("Lag")
axs[0][1].set_ylabel("Coefficiente di correlazione")
axs[0][1].set_title("Autocorrelazione sul valore di TSLA nel periodo 01/02/2018 - 02/02/2021")
axs[0][1].grid(True)

axs[1][0].plot(lags, r2, marker='.', color='#07c3ed', markersize=2)
axs[1][0].set_xlabel("Lag")
axs[1][0].set_ylabel("r²")
axs[1][0].set_title("Autocorrelazione (r²)")
axs[1][0].grid(True)

axs[1][1].plot(lags, p_values, marker='.', color='#c707ed', markersize=2)
axs[1][1].set_xlabel("Lag")
axs[1][1].set_ylabel("p-value")
axs[1][1].set_title("Significatività statistica")
axs[1][1].grid(True)

plt.show()

