import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from datetime import datetime

df = pd.read_csv('TSLA.csv', parse_dates=['Date'])
df.sort_values('Date', inplace=True)

dates_ordinal = df['Date'].map(datetime.toordinal).values #Conversione delle date in numeri ordinali ai fini della regressione
x0 = dates_ordinal - dates_ordinal.min() #Normalizzazione delle date per evitare overflow
values = df['Close'].values

#Definizione del modello non lineare
def exp_model(x, a, b, c):
    return a * np.exp(b * x) + c

initial_guess = (1, 1e-3, 1)
popt, pcov = curve_fit(exp_model, x0, values, p0=initial_guess)
(a_opt, b_opt, c_opt) = popt

x0_fit = np.linspace(x0.min(), x0.max(), 1000)
y_fit  = exp_model(x0_fit, *popt)

y_pred = exp_model(x0, *popt)
ss_res = np.sum((values - y_pred) ** 2)
ss_tot = np.sum((values - np.mean(values)) ** 2)
r_squared = 1 - (ss_res / ss_tot)

title_str = f"Parametri ottimali: a={a_opt:.4f}, b={b_opt:.6f}, c={c_opt:.4f}"
print(title_str)
print(f"R^2: {r_squared:.4f}")

dates_fit = [df['Date'].min() + pd.Timedelta(days=float(x)) for x in x0_fit]
plt.figure(figsize=(12, 6))
plt.scatter(df['Date'], values, label='Dati originali', s=2, color='#eb4034')
plt.plot(dates_fit, y_fit, label='Fit esponenziale', linewidth=2, color='#3498eb')
plt.xlabel('Data')
plt.ylabel('Valore')
plt.title('Regressione non lineare (modello esponenziale) su TSLA')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
