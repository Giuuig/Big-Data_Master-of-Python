import pandas as pd
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as sch
from sklearn.cluster import AgglomerativeClustering
import numpy as np


df = pd.read_csv("Mall_Customers.csv")

#Selezioniamo solo le colonne del dataset che ci serviranno per organizzare i cluster
X = df[["Annual Income (k$)", "Spending Score (1-100)"]].values

#Dendogramma
plt.figure(figsize=(10, 7))
plt.title("Dendrogramma")
dendrogramma = sch.dendrogram(sch.linkage(X, method='ward'))
plt.xlabel("Clienti (ID)")
plt.ylabel("Distanza Euclidea")
plt.grid(True)
plt.tight_layout()
plt.show()

#Abbiamo utilizzato Agglomerative Clustering scegliendo di dividere il dataset in cinque cluster (quantità arbitraria)
modello_cluster = AgglomerativeClustering(n_clusters=5, linkage='ward')
y_clusters = modello_cluster.fit_predict(X)

#Abbiamo utilizzato uno scatter plot per visualizzare graficamente i cluster
plt.figure(figsize=(8, 6))
for cluster in np.unique(y_clusters):
    plt.scatter(X[y_clusters == cluster, 0], X[y_clusters == cluster, 1], label=f'Cluster {cluster + 1}', marker='x')

plt.title('Cluster dei clienti (Agglomerative Clustering)')
plt.xlabel('Reddito Annuale (in migliaia di $)')
plt.ylabel('Punteggio di Spesa (1-100)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
