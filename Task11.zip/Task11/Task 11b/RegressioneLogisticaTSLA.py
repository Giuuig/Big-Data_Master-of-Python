import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#Definizione di funzioni utili per lo script
def sigmoidale(z):
    return 1 / (1 + np.exp(-z))

def log_loss(y_true, y_pred):
    epsilon = 1e-15
    y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
    return -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))

def calcolaGradienti(X, y, beta, c):
    z = X.dot(beta) + c
    predizione = sigmoidale(z)
    errore = y - predizione
    grad_beta = -np.dot(X.T, errore) / len(y)
    grad_c = -np.mean(errore)
    return grad_beta, grad_c

def accuracy(y_true, y_pred_probs, threshold=0.5):
    predizione_y = (y_pred_probs >= threshold).astype(int)
    return np.mean(predizione_y == y_true)

df = pd.read_csv('TSLA.csv')
df['Target'] = (df['Close'].shift(-1) > df['Close']).astype(int)
df = df[:-1].reset_index(drop=True)

#Dato che usiamo Close come variabile indipendente, occorre standardizzarla
X = df['Close'].values.reshape(-1, 1)
y = df['Target'].values

X_mean = X.mean()
X_std = X.std()
X_stdized = (X - X_mean) / X_std

#Inizializzazione di beta e c
beta = np.array([0.0])
c = 0.0

#Gradient descent con dieci iterazioni
learning_rate = 0.1
n_iterazioni = 10
losses = []
betas = [beta.copy()]
cs = [c]

for i in range(n_iterazioni):
    predizione = sigmoidale(X_stdized.dot(beta) + c)
    loss = log_loss(y, predizione)
    grad_beta, grad_c = calcolaGradienti(X_stdized, y, beta, c)
    beta -= learning_rate * grad_beta
    c -= learning_rate * grad_c
    losses.append(loss)
    betas.append(beta.copy())
    cs.append(c)

#Calcolo dell'accuracy
final_preds = sigmoidale(X_stdized.dot(beta) + c)
acc = accuracy(y, final_preds)
print("Accuracy finale:", acc)

#Stampa dei valori che ottimizzano il log-loss medio
print("Valore finale di beta:", beta[0])
print("Valore finale di c:", c)
print("Log-loss finale:", losses[-1])

#Visualizzazione funzione sigmoidale
z = X_stdized.dot(beta) + c
probs = sigmoidale(z)
sorted_indices = np.argsort(X_stdized[:, 0])
X_sorted = X_stdized[sorted_indices]
probs_sorted = probs[sorted_indices]

plt.figure(figsize=(10, 6))
plt.plot(X_sorted, probs_sorted, label='Funzione Sigmoidale - Probabilità di crescita della stock value di TSLA', linewidth=2, color='#ed07d6')
plt.scatter(X_stdized, y, alpha=0.3, label='Target (0=scende, 1=sale)', color='red')
plt.title("Modello Sigmoidale sui Prezzi di Chiusura di TSLA (Standardizzati)")
plt.xlabel("Prezzo di Chiusura Standardizzato")
plt.ylabel("Probabilità di Crescita")
plt.legend()
plt.grid(True)
plt.show()
