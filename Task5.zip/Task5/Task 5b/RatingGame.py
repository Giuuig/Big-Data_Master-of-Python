import trueskill
import random

env = trueskill.TrueSkill(draw_probability=0.1)

#Creazione dei giocatori
giocatori = ["Alpha", "Beta", "Gamma", "Delta"]
#Creazione del dizionario dei ratings
ratings = {name: env.create_rating() for name in giocatori}

"""
In Trueskill, il punteggio viene delineato sottoforma di variabile a distribuzione normale.
Pertanto, il metodo di print che andiamo qui a definire deve tenere in considerazione entrambi i parametri.
"""
def print_ratings(message, ratings_dict):
    print(message)
    for name, rating in ratings_dict.items():
        print(f"{name}: mu={rating.mu:.2f}, sigma={rating.sigma:.2f}")
    print("\n")

def s1vs1(player1, player2):
    winner = random.choice([p1,p2])
    if winner == player1:
        new_rating1, new_rating2 = env.rate_1vs1(ratings[player1], ratings[player2])
    else:
        new_rating2, new_rating1 = env.rate_1vs1(ratings[player2], ratings[player1])
    ratings[player1] = new_rating1
    ratings[player2] = new_rating2

def s2vs2(team_A, team_B):
    winner = random.choice(["teamA", "teamB"])
    if winner == "teamA":
        new_team_A, new_team_B = env.rate([team_A, team_B])
    else:
        new_team_B, new_team_A = env.rate([team_B, team_A])
    team_A = new_team_A
    team_B = new_team_B

for _ in range(10):
    p1, p2 = random.sample(giocatori, 2)
    s1vs1(p1, p2)
print_ratings("Risultati dopo 10 partite 1vs1 con esito casuale:", ratings)

team_A = [ratings["Alpha"], ratings["Beta"]]
team_B = [ratings["Gamma"], ratings["Delta"]]

for i in range(10):
    s2vs2(team_A, team_B)
    ratings["Alpha"], ratings["Beta"] = team_A
    ratings["Gamma"], ratings["Delta"] = team_B

print_ratings("Risultati dopo 10 partite a squadre con esito casuale (Squadra A vs Squadra B):", ratings)
