import trueskill
import random

#Per comodità, il kwarg draw_probability lo settiamo a 0.1
env = trueskill.TrueSkill(draw_probability=0.1)

#Creiamo alcuni giocatori(per comodità, 4)
giocatori = ["Alpha", "Beta", "Gamma", "Delta"]
#Creiamo il dizionario contenente i giocatori ed il rispettivo rating, che verrà aggiornato 
ratings = {nome: env.create_rating() for nome in giocatori}

"""
In Trueskill, il punteggio viene delineato sottoforma di variabile a distribuzione normale.
Pertanto, il metodo di print che andiamo qui a definire deve tenere in considerazione entrambi i parametri.
"""
def print_ratings(message, ratings_dict):
    print(message)
    for nome, rating in ratings_dict.items():
        print(f"{nome}: mu={rating.mu:.2f}, sigma={rating.sigma:.2f}")
    print("\n")

#Con questa funzione simuliamo l'andamento di una partita partita 1v1.
def s1vs1(giocatore1, giocatore2):
    winner = random.choice([giocatore1, giocatore2])
    if winner == giocatore1:
        new_rating1, new_rating2 = env.rate_1vs1(ratings[giocatore1], ratings[giocatore2])
    else:
        new_rating2, new_rating1 = env.rate_1vs1(ratings[giocatore2], ratings[giocatore1])
    ratings[giocatore1] = new_rating1
    ratings[giocatore2] = new_rating2

#Il 2v2 lo abbiamo implementato esattamente come nel 1v1
def s2vs2(team_A, team_B):
    winner = random.choice(["teamA", "teamB"])
    if winner == "teamA":
        new_team_A, new_team_B = env.rate([team_A, team_B])
    else:
        new_team_B, new_team_A = env.rate([team_B, team_A])
    team_A = new_team_A
    team_B = new_team_B

#Eseguiamo 10 partite 1vs1 con esito casuale.
for x in range(10):
    p1, p2 = random.sample(giocatori, 2)
    s1vs1(p1, p2)
print_ratings("Risultati dopo 10 partite 1vs1 casuali:", ratings)

#Costruiamo due squadre
team_A = [ratings["Alpha"], ratings["Beta"]]
team_B = [ratings["Gamma"], ratings["Delta"]]

#Eseguiamo 10 partite a squadre con esito casuale.
for i in range(10):
    s2vs2(team_A, team_B)
    # Aggiorniamo i rating dei singoli giocatori
    ratings["Alpha"], ratings["Beta"] = team_A
    ratings["Gamma"], ratings["Delta"] = team_B

print_ratings("Risultati dopo 10 partite a squadre con esito casuale (Squadra A vs Squadra B):", ratings)
