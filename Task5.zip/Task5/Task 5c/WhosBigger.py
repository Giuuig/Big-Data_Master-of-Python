import wikipedia
import trueskill
import itertools

#Supponendo di operare con le pagine in italiano, settiamo la lingua italiana per Wikipedia
wikipedia.set_lang("it")

candidates = [
    "Romolo",
    "Giulio Cesare",
    "Dante Alighieri",
    "Leonardo Da Vinci",
    "Benito Mussolini",
    "Umberto II di Savoia",
    "Rita Levi Montalcini",
    "Alessandro Manzoni",
    "Mario Draghi"
]

ratings = { candidate: trueskill.Rating() for candidate in candidates }

#Parametri e relativi pesi
weights = {
    "content_length": 0.6, 
    "references": 0.4,     
    "images": 0.1,          
    "links": 0.2            
}

#Dizionario in cui vengono salvati i dati utili alla definizione dei quattro parametri per ogni personaggio
data = {}

print("Recupero dati da Wikipedia:")
for candidate in candidates:
    try:
        page = wikipedia.page(candidate)
        content_length = len(page.content)
        references_count = len(page.references)
        images_count = len(page.images)
        links_count = len(page.links)

        data[candidate] = {
            "content_length": content_length,
            "references": references_count,
            "images": images_count,
            "links": links_count
        }
        print(f"  {candidate}: content_length = {content_length}, references = {references_count}, images = {images_count}, links = {links_count}")
    except Exception as e:
        print(f"  Errore per {candidate}: {e}")
        #Nel caso in cui il candidato non esista su Wikipedia, si assegna di default 0 per ogni campo valutato
        data[candidate] = {
            "content_length": 0,
            "references": 0,
            "images": 0,
            "links": 0
        }

#Normalizzazione dei punteggi
max_values = {}
for factor in weights.keys():
    max_values[factor] = max(data[candidate][factor] for candidate in candidates)

scores = {}
print("\nCalcolo dei punteggi:")
for candidate in candidates:
    factors = data[candidate]
    composite_score = 0.0
    for factor, weight in weights.items():
        max_val = max_values[factor]
        #Se il valore massimo rilevato è maggiore di 0 si fa una normalizzazione, altrimenti la variabile va a 0
        normalized = factors[factor] / max_val if max_val > 0 else 0
        composite_score += weight * normalized
    scores[candidate] = composite_score
    print(f"  {candidate}: Composite Score = {composite_score:.4f}")


#Simulazioni 1v1 
for candidate1, candidate2 in itertools.combinations(candidates, 2):
    score1 = scores[candidate1]
    score2 = scores[candidate2]
    print("Match tra", candidate1, " e ", candidate2)
    if score1 == score2:
        ratings[candidate1], ratings[candidate2] = trueskill.rate_1vs1(
            ratings[candidate1], ratings[candidate2], drawn=True
        )
        print("Pareggio!")
    elif score1 > score2:
        ratings[candidate1], ratings[candidate2] = trueskill.rate_1vs1(
            ratings[candidate1], ratings[candidate2]
        )
        print("La vittoria va a", candidate1)
    else:
        ratings[candidate2], ratings[candidate1] = trueskill.rate_1vs1(
            ratings[candidate2], ratings[candidate1]
        )
        print("La vittoria va a", candidate2)

#Ordine dei candidati in base al rating (usando mu come indicatore)
ranking = sorted(ratings.items(), key=lambda x: x[1].mu, reverse=True)

print("\nRanking finale (Who is Bigger):")
for candidate, rating in ranking:
    print(f"{candidate}: mu = {rating.mu:.2f}, sigma = {rating.sigma:.2f}")