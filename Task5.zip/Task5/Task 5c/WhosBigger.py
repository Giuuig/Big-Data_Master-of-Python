import wikipedia
import trueskill
import itertools

#Supponendo di operare con le pagine in italiano, abbiamo settato la lingua italiana per Wikipedia
wikipedia.set_lang("it")

#Costruiamo una lista di stringhe contenente i nomi dei personaggi per cui vogliamo fare il rating
candidati = [
    "Romolo", 
    "Giulio Cesare", 
    "Dante Alighieri", 
    "Leonardo Da Vinci", 
    "Benito Mussolini", 
    "Umberto II di Savoia", 
    "Rita Levi Montalcini", 
    "Alessandro Manzoni", 
    "Mario Draghi"
]

#Qui costruiamo un dizionario in cui salvare i rating dei personaggi "in gara"
ratings = {candidato: trueskill.Rating() for candidato in candidati}

"""
Dal momento che stiamo effettuando un rating sulla base di quattro parametri, abbiamo deciso di attribuire un peso a ciascuno di loro.
Abbiamo deciso di attribuire i pesi in maniera arbitraria, ma al fine di risolvere eventuali ex equo tra i candidati.
"""
pesi = {
    "lunghezza_contenuto": 0.6,  # lunghezza del contenuto
    "riferimenti": 0.4,      # numero di riferimenti
    "immagini": 0.1,          # numero di immagini
    "links": 0.2            # numero di link interni/esterni
}

#In questo dizionario salviamo le informazioni ricavate per ciascun personaggio in gara
dati = {}

print("Recupero dati da Wikipedia:")
for candidato in candidati:
    try:
        pagina = wikipedia.page(candidato)
        lunghezza_contenuto = len(pagina.content)
        riferimenti = len(pagina.references)
        immagini = len(pagina.images)
        links = len(pagina.links)
        
        dati[candidato] = {
            "lunghezza_contenuto": lunghezza_contenuto,
            "riferimenti": riferimenti,
            "immagini": immagini,
            "links": links
        }
        print(f"{candidato}: lunghezza_contenuto = {lunghezza_contenuto}, riferimenti = {riferimenti}, immagini = {immagini}, links = {links}")
    except Exception as e:
        print(f"Errore per {candidato}: {e}")
        #Nel caso in cui il candidato non esista su Wikipedia, decidiamo di assegnargli di default 0 per ogni campo valutato
        dati[candidato] = {
            "lunghezza_contenuto": 0,
            "riferimenti": 0,
            "immagini": 0,
            "links": 0
        }

"""
Prevediamo di normalizzare i punteggi rilevati ai fini del confronto tra i vari candidati.
Pertanto, per ciascuna categoria rilevata vado a cercare il valore massimo che è stato rilevato
"""
valori_massimi = {}
for x in pesi.keys():
    valori_massimi[x] = max(dati[candidato][x] for candidato in candidati)

#Procediamo al calcolo del punteggio composito per ciascun candidato
punteggi = {}
print("\nCalcolo dei punteggi:")
for candidato in candidati:
    indicatori = dati[candidato]
    punteggio_composto = 0.0
    for indicatore, peso in pesi.items():
        max_val = valori_massimi[indicatore]
        #Se il valore massimo rilevato è maggiore di 0 effettuiamo una normalizzazione, altrimenti settiamo la variabile a 0
        normalizzazione = indicatori[indicatore] / max_val if max_val > 0 else 0
        punteggio_composto += peso * normalizzazione
    #A questo punto, abbiamo il punteggio composto per ciascun candidato
    punteggi[candidato] = punteggio_composto
    print(f"  {candidato}: Composite Score = {punteggio_composto:.4f}")

"""
Tramite l'uso di Trueskill effettuiamo dei match singoli tra i vari personaggi
Vince chi ha il punteggio composito più alto (è previsto il pareggio se i punteggi si equivalgono)
"""

for candidato1, candidato2 in itertools.combinations(candidati, 2):
    punteggio1 = punteggi[candidato1]
    punteggio2 = punteggi[candidato2]
    print("Match tra", candidato1, " e ", candidato2)
    if punteggio1 == punteggio2:
        ratings[candidato1], ratings[candidato2] = trueskill.rate_1vs1(
            ratings[candidato1], ratings[candidato2], drawn=True
        )
        print("Pareggio!")
    elif punteggio1 > punteggio2:
        ratings[candidato1], ratings[candidato2] = trueskill.rate_1vs1(
            ratings[candidato1], ratings[candidato2]
        )
        print("La vittoria va a", candidato1)
    else:
        ratings[candidato2], ratings[candidato1] = trueskill.rate_1vs1(
            ratings[candidato2], ratings[candidato1]
        )
        print("La vittoria va a", candidato2)

# Ordina i candidati in base al rating (usando mu come indicatore)
classifica = sorted(ratings.items(), key=lambda x: x[1].mu, reverse=True)

print("\nRanking finale (Who is Bigger):")
for candidato, rating in classifica:
    print(f"{candidato}: mu = {rating.mu:.2f}, sigma = {rating.sigma:.2f}")
