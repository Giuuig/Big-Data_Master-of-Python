import pandas as pd  

df = pd.read_csv("C:\\Users\\anton\\Desktop\\Uninsubria\\Anno II\\24.25\\Big Data\\Tasks\\Task5\\dataset_altezza_peso_giocatori.csv")
df.to_excel('dataset_giocatori.xlsx', index=False)

