import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np

Campione_Italiani = pd.read_excel("dataset_altezza_peso_italia.xlsx")
Campione_Calciatori = pd.read_excel("dataset_altezza_peso_giocatori.xlsx")

BMI_Ita = []
BMI_Calc = []

#Funzione definita per stabilire come assegnare i colori nel grafico
def get_color(bmi):
    if bmi < 18.5:
        return '#0297fa' #Sottopeso
    elif bmi < 25:
        return '#fabc02' #Normopeso
    else:
        return '#fa027e' #Sovrappeso

#Costruzione di una nuova colonna contenente l'altezza espressa in metri (al fine di semplificare i calcoli)
Campione_Italiani['Altezza_m'] = Campione_Italiani['Altezza_cm']/100
Campione_Calciatori['Altezza_m'] = Campione_Calciatori['Altezza']/100

BMI_Ita = (Campione_Italiani['Peso_kg']/(Campione_Italiani['Altezza_m']**2)).tolist()
BMI_Calc = (Campione_Calciatori['Peso']/(Campione_Calciatori['Altezza_m']**2)).tolist()

colors1 = [get_color(b) for b in BMI_Ita]
colors2 = [get_color(b) for b in BMI_Calc]

legend_elements = [
    Patch(facecolor='#0297fa', edgecolor='k', label='Sottopeso'),
    Patch(facecolor='#fabc02', edgecolor='k', label='Normopeso'),
    Patch(facecolor='#fa027e', edgecolor='k', label='Sovrappeso')
]

fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(10,5), sharex=False)
fig.suptitle("Confronto tra due dataset con categorizzazione per BMI")
axs[0].scatter(Campione_Italiani['Peso_kg'],Campione_Italiani['Altezza_m'], c=colors1, edgecolor='k', marker='o', alpha=0.7, label="Dati sul BMI di un campione della popolazione italiana")
axs[0].set_xlabel("Peso (kg)")
axs[0].set_ylabel("Altezza (m)")

axs[1].scatter(Campione_Calciatori['Peso'],Campione_Calciatori['Altezza_m'], c=colors2, edgecolor='k', marker='o', alpha=0.7, label="Dati sul BMI dei calciatori della serie A")
axs[1].set_xlabel("Peso (kg)")
axs[1].set_ylabel("Altezza (m)")
fig.legend(handles=legend_elements)
plt.show()