import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np

#Abbiamo convertito i due file da csv a excel e gestito i parsing di tipo direttamente a livello di file e non di script in Python
Campione_Italiani = pd.read_excel('dataset_altezza_peso_italia.xlsx')
Campione_Calciatori = pd.read_excel('dataset_altezza_peso_giocatori.xlsx')

BMI_Ita = []
BMI_Calc = []

#Questa funzione l'abbiamo definita per arricchire il grafico (tracciamo cioè in quale area del grafico abbiamo i sovrappeso, i normopeso e i sottopeso)
def get_color(bmi):
    if bmi < 18.5:
        return '#0297fa' #Sottopeso
    elif bmi < 25:
        return '#fabc02' #Normopeso
    else:
        return '#fa027e' #Sovrappeso

#Ai fini del calcolo, costruiamo una nuova colonna contenente l'altezza espressa in metri
Campione_Italiani['Altezza_m'] = Campione_Italiani['Altezza_cm']/100
Campione_Calciatori['Altezza_m'] = Campione_Calciatori['Altezza']/100

#Abbiamo poi calcolato il BMI per ciascun campione dei due dataframe e salvato il risultato in una lista
BMI_Ita = (Campione_Italiani['Peso_kg']/(Campione_Italiani['Altezza_m']**2)).tolist()
BMI_Calc = (Campione_Calciatori['Peso']/(Campione_Calciatori['Altezza_m']**2)).tolist()

#Generiamo una lista in cui attribuiamo un colore a ciascun BMI calcolato in base alla categoria di appartenenza tra quelle che abbiamo dichiarato poco sopra
#In questo modo, possiamo passare la lista di colori ottenuta al grafico e quindi colorare i punti in base alla categoria d'appartenenza
coloriIta = [get_color(b) for b in BMI_Ita]
coloriCalciatori = [get_color(b) for b in BMI_Calc]

legenda = [
    Patch(facecolor='#0297fa', edgecolor='k', label='Sottopeso'),
    Patch(facecolor='#fabc02', edgecolor='k', label='Normopeso'),
    Patch(facecolor='#fa027e', edgecolor='k', label='Sovrappeso')
]

fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(10,5), sharex=False)
fig.suptitle("Confronto tra due dataset con categorizzazione per BMI")
axs[0].scatter(Campione_Italiani['Peso_kg'],Campione_Italiani['Altezza_m'], c=coloriIta, edgecolor='k', marker='o', alpha=0.7, label="Dati sul BMI di un campione della popolazione italiana")
axs[0].set_xlabel("Peso (kg)")
axs[0].set_ylabel("Altezza (m)")
"""
Il dataset sulla popolazione italiana comprende un campione di 10k valori, mentre quello dei calciatori sono ca 500. Per questo,
abbiamo optato per l'uso della scala logaritmica sul primo grafico
"""
axs[0].set_xscale('log')
axs[0].set_yscale('log')

axs[1].scatter(Campione_Calciatori['Peso'],Campione_Calciatori['Altezza_m'], c=coloriCalciatori, edgecolor='k', marker='o', alpha=0.7, label="Dati sul BMI dei calciatori della serie A")
axs[1].set_xlabel("Peso (kg)")
axs[1].set_ylabel("Altezza (m)")
fig.legend(handles=legenda)
plt.show()