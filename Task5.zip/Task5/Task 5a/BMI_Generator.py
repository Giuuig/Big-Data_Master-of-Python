# Generating synthetic dataset for height and weight for the Italian population

import numpy as np
import pandas as pd

# Imposta il seme per la riproducibilità
np.random.seed(42)

# Numero di record: decine di migliaia (es. 50.000)
n = 5000

# Genera i dati per l'altezza (in cm)
# Distribuzione normale con media 165 cm e deviazione standard 8 cm, 
# limitata tra 140 e 200 cm per valori realistici.
altezza = np.clip(np.random.normal(165, 8, n), 140, 200)

# Genera i dati per il peso (in kg)
# Si assume una relazione approssimativa: peso ~ (altezza - 100) + rumore casuale.
# Aggiungiamo del rumore distribuito normalmente con media 0 e deviazione standard 8 kg.
peso = np.clip((altezza - 100) + np.random.normal(0, 8, n), 40, 120)

# Crea un DataFrame con le colonne: ID, Altezza in cm, Peso in kg.
df = pd.DataFrame({
    'ID': np.arange(1, n+1),
    'Altezza_cm': np.round(altezza, 1),
    'Peso_kg': np.round(peso, 1)
})

# Salva il DataFrame in un file Excel
excel_file = "dataset_altezza_peso_italia.xlsx"
df.to_excel(excel_file, index=False)

excel_file  # output the file name for confirmation

