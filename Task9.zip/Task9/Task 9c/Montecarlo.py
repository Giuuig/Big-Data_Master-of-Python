import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math
import sys 

sys.stdout.reconfigure(encoding='utf-8')

#Definizione dei parametri da utilizzare nell'esperimento
A_min, A_max = 9000, 15000
B_min, B_max = 11000, 12000
C_min, C_max = 5200, 5500
D_min, D_max = 9900, 12300
E_min, E_max = 15000, 17000

Tot_Max = A_max + B_max + C_max + D_max + E_max
std_dev = 5850
error_max_req = 0.05
error_abs = 2797.5
z = 3

#Calcolo del numero di iterazioni necessarie per la simulazione Monte Carlo
n_iter = (z * std_dev / error_abs) ** 2
n_iter_int = int(n_iter)

print("Step1: Calcolo numero iterazioni Monte Carlo")
print(f"Totale valore massimo portafoglio: {Tot_Max}")
print(f"Dev. Std: {std_dev}")
print(f"Errore massimo richiesto: {error_max_req}")
print(f"Errore assoluto: {error_abs}")
print(f"Numero iterazioni Monte Carlo (calcolato): {n_iter:.2f}")
print(f"Numero iterazioni (intero): {n_iter_int}")

#Si effettua la simulazione di Monte Carlo
np.random.seed(0)
results = pd.DataFrame({
    'A': np.random.uniform(A_min, A_max, n_iter_int),
    'B': np.random.uniform(B_min, B_max, n_iter_int),
    'C': np.random.uniform(C_min, C_max, n_iter_int),
    'D': np.random.uniform(D_min, D_max, n_iter_int),
    'E': np.random.uniform(E_min, E_max, n_iter_int)
})
results['Tot_Portafoglio'] = results.sum(axis=1)

#Calcolo della probabilità di perdita e di guadagno
invest = 55000
prob_loss = (results['Tot_Portafoglio'] < invest).mean()
prob_gain_5000 = (results['Tot_Portafoglio'] >= invest + 5000).mean()

print("\nStep3: Probabilità")
print(f"Probabilità di perdere soldi (Tot_Portafoglio < {invest}): {prob_loss:.6f}")
print(f"Probabilità di guadagno ≥5000€ (Tot_Portafoglio ≥ {invest + 5000}): {prob_gain_5000:.6f}")

#Istogramma della distribuzione del valore finale del portafoglio
plt.figure()
plt.hist(results['Tot_Portafoglio'], bins=30)         
plt.axvline(invest, linestyle='--')                   #Linea soglia perdita
plt.axvline(invest + 5000, linestyle='--')            #Linea soglia guadagno ≥5000€
plt.title('Distribuzione del Valore Totale del Portafoglio')
plt.xlabel('Valore Totale (€)')
plt.ylabel('Frequenza')
plt.tight_layout()
plt.show()

#Andamento del valore del portafoglio ad ogni iterazione
plt.figure()
plt.plot(results['Tot_Portafoglio'])                  
plt.title('Andamento del Portafoglio per Iterazione')
plt.xlabel('Numero Iterazione')
plt.ylabel('Valore Totale (€)')
plt.tight_layout()
plt.show()

