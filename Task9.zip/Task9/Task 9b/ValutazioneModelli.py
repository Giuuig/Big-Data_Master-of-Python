import pandas as pd
import matplotlib.pyplot as plt

dataset = 'CovidDataset.xlsx'
df = pd.read_excel(dataset)

#Pulizia del dataset per rimuovere la riga finale, contenente i totali, per evitare di inquinare i calcoli
df_pulito = df[~df['Dosage'].str.contains("tot\\.|Tot\\.|TOTAL", case=False, na=False)]

#Funzione per calcolare dose media dato un intervallo selezionato
def extract_avg_dosage(dosaggio):
    dosaggio = dosaggio.strip()
    if dosaggio.startswith("<"):
        return float(dosaggio.replace("<", "").strip()) - 0.01
    elif dosaggio.startswith(">"):
        return float(dosaggio.replace(">", "").strip()) + 0.01
    elif "-" in dosaggio:
        partizioni = dosaggio.split("-")
        return (float(partizioni[0].strip()) + float(partizioni[1].strip())) / 2
    else:
        return float(dosaggio)

#Inserimento nel dataset di una colonna dedicata alle dosi medie
df_pulito['AvgDosage'] = df_pulito['Dosage'].apply(extract_avg_dosage)

#Espansione dei dati del dataset in modo da avere una riga per ogni campione positivo e negativo
expanded_data = []
for _, row in df_pulito.iterrows():
    expanded_data.extend([{'Dosage': row['AvgDosage'], 'Label': 0}] * int(row['Negative']))
    expanded_data.extend([{'Dosage': row['AvgDosage'], 'Label': 1}] * int(row['Positive']))

df_espanso = pd.DataFrame(expanded_data)

#Definizione del cut-off e della confusion matrix. Calcolo delle metriche relative alla positività e alla negatività
cutoff = 5
df_espanso['Prediction'] = (df_espanso['Dosage'] >= cutoff).astype(int)

#Veri Positivi
VP = ((df_espanso['Prediction'] == 1) & (df_espanso['Label'] == 1)).sum()
#Veri Negativi
VN = ((df_espanso['Prediction'] == 0) & (df_espanso['Label'] == 0)).sum()
#Falsi Positivi
FP = ((df_espanso['Prediction'] == 1) & (df_espanso['Label'] == 0)).sum()
#Falsi Negativi
FN = ((df_espanso['Prediction'] == 0) & (df_espanso['Label'] == 1)).sum()

accuratezza = (VP + VN) / (VP + VN + FP + FN)
#True Positive Rate
TPR = VP / (VP + FN) if (VP + FN) > 0 else 0
#True Negative Rate
TNR = VN / (VN + FP) if (VN + FP) > 0 else 0
#False Positive Rate
FPR = FP / (FP + VN) if (FP + VN) > 0 else 0
#Positive Predictive Value
PPV = VP / (VP + FP) if (VP + FP) > 0 else 0
#Negative Predictive Value
NPV = VN / (VN + FN) if (VN + FN) > 0 else 0

print("Confusion Matrix e metriche rispetto al cutoff =", cutoff)
print(f"VP: {VP}, VN: {VN}, FP: {FP}, FN: {FN}")
print(f"Accuratezza: {accuratezza:.2f}")
print(f"True Positive Rate (TPR): {TPR:.2f}")
print(f"True Negative Rate (TNR): {TNR:.2f}")
print(f"False Positive Rate (FPR): {FPR:.2f}")
print(f"Positive Predictive Value (PPV): {PPV:.2f}")
print(f"Negative Predictive Value (NPV): {NPV:.2f}")

#Costruzione della ROC table
roc_table = []
valori_soglia = sorted(df_espanso['Dosage'].unique())

for soglie in valori_soglia:
    previsioni = (df_espanso['Dosage'] > soglie).astype(int)
    TP = ((previsioni == 1) & (df_espanso['Label'] == 1)).sum()
    TN = ((previsioni == 0) & (df_espanso['Label'] == 0)).sum()
    FP = ((previsioni == 1) & (df_espanso['Label'] == 0)).sum()
    FN = ((previsioni == 0) & (df_espanso['Label'] == 1)).sum()

    TPR = TP / (TP + FN) if (TP + FN) > 0 else 0
    FPR = FP / (FP + TN) if (FP + TN) > 0 else 0
    youden = TPR - FPR

    roc_table.append({'Soglia': soglie, 'TPR': TPR, 'FPR': FPR, 'YoudenIndex': youden})

roc_df = pd.DataFrame(roc_table).sort_values(by='YoudenIndex', ascending=False)

#Miglior valore soglia secondo l'indice di Youden per vedere dove si trova il punto in cui il modello si comporta in maniera ottimale
best_row = roc_df.iloc[0]
print("\nMiglior dosaggio secondo l'Indice di Youden:")
print(best_row)

plt.figure(figsize=(6, 6))
plt.scatter(roc_df['FPR'], roc_df['TPR'])
plt.plot([0, 1], [0, 1], 'k--')
plt.title('Curva ROC')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.grid(True)
plt.tight_layout()
plt.show()
