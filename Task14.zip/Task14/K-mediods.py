import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import pairwise_distances
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe

#Per comodità abbiamo deciso di usare un campione di 1000 elementi
df = pd.read_csv('TA_restaurants_curated.csv')
campione = 1000
df_campione = df.sample(n=campione, random_state=42).reset_index(drop=True) if df.shape[0] > campione else df.copy()

#Abbiamo selezionato le features "numeriche" e abbiamo tolto le colonne non necessarie. La nostra idea è quella di costruire un biplot
colonne = df_campione.select_dtypes(include=[np.number]).columns.tolist()
colonne = [c for c in colonne if not c.lower().endswith('id') and not c.startswith('Unnamed')]
X = df_campione[colonne]

#ffettuiamo l'imputazione mediana e la standardizzazione
keep_cols = X.columns[X.isnull().mean() <= 0.5]
X = X[keep_cols].fillna(X[keep_cols].median())
scaler = StandardScaler()
X_Standardizzata = scaler.fit_transform(X)

#Qui abbiamo calcolato la matrice di Manhattan
M = pairwise_distances(X_Standardizzata, metric='manhattan')

#Definisco la funzione Partitioning Around Medoids 
def pam(D, k):
    n = D.shape[0]
    costs = D.sum(axis=1)
    medoids = [int(np.argmin(costs))]
    for _ in range(1, k):
        current = np.min(D[:, medoids], axis=1)
        gains = {i: current.sum() - np.minimum(current, D[:, i]).sum() for i in range(n) if i not in medoids}
        medoids.append(max(gains, key=gains.get))
    improved = True
    while improved:
        improved = False
        best_cost = np.min(D[:, medoids], axis=1).sum()
        for m in medoids:
            for o in range(n):
                if o in medoids:
                    continue
                trial = medoids.copy()
                trial[trial.index(m)] = o
                trial_cost = np.min(D[:, trial], axis=1).sum()
                if trial_cost < best_cost:
                    medoids = trial
                    best_cost = trial_cost
                    improved = True
                    break
            if improved:
                break
    return medoids

#Qui facciamo il clustering con cinque medoidi
k = 5
medoids = pam(M, k)
labels = np.argmin(M[:, medoids], axis=1)
df_campione['cluster'] = labels

#Identifichiamo i "Principal Component", che ci serviranno per costruire il biplot, tramite PCA (Principal Component Analysis)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_Standardizzata)
loadings = pca.components_.T * np.sqrt(pca.explained_variance_)

#Abbiamo definito delle palette di colori per personalizzare un po' il grafico
palette = ['#fcba03', '#03befc', '#e303fc', '#0f8a5f', '#8a0f2c']

#Costruzione del grafico
plt.figure(figsize=(12, 9))

#Costruzione dello scatter per ciascun cluster identificato
for i, color in enumerate(palette):
    mask = labels == i
    plt.scatter(X_pca[mask, 0], X_pca[mask, 1],
                c=color, s=50, alpha=0.7, label=f'Cluster {i}', marker='x')

#Rappresentiamo anche i medoidi identificati 
medoid_coords = X_pca[medoids]
plt.scatter(medoid_coords[:, 0], medoid_coords[:, 1],
            facecolors='white', edgecolors='black', marker='X', s=200, linewidths=2, label='Medoid')

#Frecce del biplot:
base_offset = 1.3
pos_adjust = {'Rating': (-0.7, -0.0), 'Ranking': (-0.4, 0.2)}

for idx, var in enumerate(keep_cols):
    x_load, y_load = loadings[idx, 0], loadings[idx, 1]
    plt.arrow(0, 0, x_load, y_load,
              head_width=0.15, head_length=0.15, linewidth=2, alpha=0.9)
    dx, dy = pos_adjust.get(var, (0, 0))
    off_x, off_y = x_load * base_offset + dx, y_load * base_offset + dy
    fontsize = 14 if var in ('Rating', 'Ranking') else 12
    plt.text(off_x, off_y,
             var,
             color='white',
             fontsize=fontsize,
             weight='bold',
             path_effects=[pe.Stroke(linewidth=1.5, foreground='black'), pe.Normal()])

plt.rcParams["font.family"] = "Arial"
plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% varianza)', fontsize=16)
plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% varianza)', fontsize=16)
plt.title('Biplot con 5 cluster e 5 medoidi', fontsize=18)

plt.legend(fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
